package com.issakib.sensi

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import java.util.Random

/** Animation helper. Call cancelAll() when the owning screen/panel goes away. */
class Fx {
    private val running = ArrayList<Animator>()
    private val handler = Handler(Looper.getMainLooper())

    fun <T : Animator> track(a: T): T { running.add(a); return a }

    fun cancelAll() {
        handler.removeCallbacksAndMessages(null)
        running.forEach { it.cancel() }
        running.clear()
    }

    fun post(delay: Long, r: () -> Unit) { handler.postDelayed({ r() }, delay) }

    fun breathe(v: View) {
        val a = ObjectAnimator.ofPropertyValuesHolder(
            v,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.06f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.06f)
        ).apply {
            duration = 1400
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
        }
        track(a).start()
    }

    fun ring(v: View, delay: Long = 0) {
        val a = ObjectAnimator.ofPropertyValuesHolder(
            v,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 0.92f, 1.35f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.92f, 1.35f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.9f, 0f)
        ).apply {
            duration = 2200
            startDelay = delay
            repeatCount = ValueAnimator.INFINITE
            interpolator = DecelerateInterpolator()
        }
        track(a).start()
    }

    fun glowBorder(c: Context, d: GradientDrawable, from: Int, to: Int) {
        val a = ValueAnimator.ofArgb(from, to).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener { d.setStroke(Ui.dp(c, 2), it.animatedValue as Int) }
        }
        track(a).start()
    }

    fun glowText(tv: TextView, c: Context, from: Int, to: Int) {
        val a = ValueAnimator.ofArgb(from, to).apply {
            duration = 1600
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener {
                val v = it.animatedValue as Int
                tv.setTextColor(v)
                tv.setShadowLayer(Ui.dp(c, 12).toFloat(), 0f, 0f, v)
            }
        }
        track(a).start()
    }

    fun blink(v: View) {
        val a = ObjectAnimator.ofFloat(v, View.ALPHA, 1f, 0.3f).apply {
            duration = 700
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
        }
        track(a).start()
    }

    fun fadeIn(v: View, delay: Long) {
        v.alpha = 0f
        v.translationY = Ui.dp(v.context, 14).toFloat()
        v.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(420).start()
    }

    /** Cyan scan line sweeping over a FrameLayout. */
    fun scan(c: Context, host: FrameLayout) {
        val h = Ui.dp(c, 40)
        val line = View(c)
        line.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x0000E5FF, 0x5500E5FF, 0x0000E5FF)
        )
        host.addView(line, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
        val a = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2800
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                line.translationY = -h + (it.animatedValue as Float) * (host.height + h)
            }
        }
        track(a).start()
    }

    /** Terminal-style typing, line by line. */
    fun typeLines(
        tv: TextView,
        lines: List<String>,
        onLine: () -> Unit = {},
        onDone: () -> Unit
    ) {
        val sb = StringBuilder()
        var li = 0
        var ci = 0
        val r = object : Runnable {
            override fun run() {
                if (li >= lines.size) {
                    tv.text = sb.toString().trimEnd('\n')
                    onDone()
                    return
                }
                val line = lines[li]
                if (ci < line.length) {
                    val end = minOf(ci + 2, line.length)
                    sb.append(line, ci, end)
                    ci = end
                    tv.text = sb.toString() + "█"
                    handler.postDelayed(this, 6)
                } else {
                    sb.append('\n')
                    li++
                    ci = 0
                    onLine()
                    handler.postDelayed(this, 90)
                }
            }
        }
        handler.post(r)
    }
}

/** Falling green code background. */
class MatrixRain(ctx: Context, private val alphaMax: Int = 80) : View(ctx) {
    private val chars = "01ABCDEF<>{}[]#%&*+=/?".toCharArray()
    private val rnd = Random()
    private val fontPx = Ui.dp(ctx, 13).toFloat()
    private val trail = 14
    private val p = Paint().apply { typeface = Typeface.MONOSPACE }
    private var cols = 1
    private var heads = FloatArray(1)
    private var speeds = FloatArray(1)
    private var tick = 0

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        p.textSize = fontPx
        cols = (w / (fontPx * 0.62f)).toInt().coerceAtLeast(1)
        heads = FloatArray(cols) { -rnd.nextInt(40).toFloat() }
        speeds = FloatArray(cols) { 0.12f + rnd.nextFloat() * 0.3f }
    }

    override fun onDraw(canvas: Canvas) {
        val cw = width.toFloat() / cols
        val rows = (height / fontPx).toInt() + 1
        for (i in 0 until cols) {
            val head = heads[i].toInt()
            for (t in 0 until trail) {
                val row = head - t
                if (row < 0 || row > rows) continue
                p.color = if (t == 0) 0xFFE0FFE0.toInt() else 0xFF39FF14.toInt()
                val a = (alphaMax * (1f - t / trail.toFloat())).toInt() + if (t == 0) 60 else 0
                p.alpha = a.coerceIn(0, 255)
                val idx = (i * 7 + row * 13 + tick / 5) % chars.size
                canvas.drawText(chars, idx, 1, i * cw, row * fontPx, p)
            }
            heads[i] += speeds[i]
            if (heads[i] - trail > rows) {
                heads[i] = -rnd.nextInt(20).toFloat()
                speeds[i] = 0.12f + rnd.nextFloat() * 0.3f
            }
        }
        tick++
        postInvalidateOnAnimation()
    }
}
