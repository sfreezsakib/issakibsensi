package com.issakib.sensi

import android.content.Context

data class Task(
    val key: String,
    val icon: String,
    val title: String,
    val sub: String,
    val url: String,
    val color: Int
)

/** Follow gate. Once every task is completed the unlock is saved permanently. */
object Gate {
    val tasks = listOf(
        Task("yt1", "▶", "YouTube", "@issakibbd", "https://www.youtube.com/@issakibbd", 0xFFFF3B3B.toInt()),
        Task("yt2", "▶", "YouTube 2", "@issakib2", "https://www.youtube.com/@issakib2", 0xFFFF7A3B.toInt()),
        Task("tg1", "✈", "Telegram", "@issakib", "https://t.me/issakib", 0xFF29B6F6.toInt()),
        Task("tg2", "✈", "Telegram 2", "@issakibbd", "https://t.me/issakibbd", 0xFF00E5FF.toInt()),
        Task("tt", "♪", "TikTok", "@issakibff", "https://www.tiktok.com/@issakibff", 0xFFB026FF.toInt())
    )

    private fun p(c: Context) = c.getSharedPreferences("gate", Context.MODE_PRIVATE)

    fun done(c: Context, key: String) = p(c).getBoolean(key, false)

    fun unlocked(c: Context) = p(c).getBoolean("unlocked", false)

    fun markDone(c: Context, key: String) {
        val e = p(c).edit().putBoolean(key, true)
        val all = tasks.all { it.key == key || p(c).getBoolean(it.key, false) }
        if (all) e.putBoolean("unlocked", true)
        e.apply()
    }

    fun count(c: Context) = tasks.count { done(c, it.key) }
}
