package com.issakib.sensi

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

object Ui {
    val BG = 0xF0070A1A.toInt()
    val CYAN = 0xFF00E5FF.toInt()
    val PURPLE = 0xFFB026FF.toInt()
    val GREEN = 0xFF39FF14.toInt()
    val RED = 0xFFFF3B5C.toInt()
    val TEXT = 0xFFCFE9FF.toInt()

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun box(c: Context, fill: Int = BG, stroke: Int = CYAN, radius: Int = 14) =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(c, radius).toFloat()
            setStroke(dp(c, 2), stroke)
        }

    fun text(
        c: Context, s: String, size: Float = 13f, color: Int = TEXT,
        bold: Boolean = false, glow: Int = 0
    ) = TextView(c).apply {
        text = s
        textSize = size
        setTextColor(color)
        typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        if (glow != 0) setShadowLayer(dp(c, 8).toFloat(), 0f, 0f, glow)
    }

    fun button(c: Context, s: String, color: Int, onClick: () -> Unit) =
        text(c, s, 14f, Color.WHITE, true, color).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
            setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
            background = box(c, (color and 0x00FFFFFF) or 0x55000000, color)
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
                false
            }
            setOnClickListener { onClick() }
        }

    fun ring(c: Context, color: Int, radiusDp: Int, strokeDp: Int = 3) = View(c).apply {
        background = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = dp(c, radiusDp).toFloat()
            setStroke(dp(c, strokeDp), color)
        }
    }

    fun logoView(c: Context, radiusDp: Int) = ImageView(c).apply {
        setImageResource(R.drawable.logo)
        scaleType = ImageView.ScaleType.FIT_XY
        background = GradientDrawable().apply {
            setColor(Color.BLACK)
            cornerRadius = dp(c, radiusDp).toFloat()
        }
        clipToOutline = true
        outlineProvider = ViewOutlineProvider.BACKGROUND
    }

    fun scroll(c: Context, child: View) = ScrollView(c).apply {
        descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        isVerticalScrollBarEnabled = false
        addView(child)
    }

    fun seekRow(c: Context, label: String, init: Int): LinearLayout {
        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(c, 2), 0, dp(c, 2))
        }
        val name = text(c, label, 12f, TEXT)
        val value = text(c, init.toString(), 13f, GREEN, true, GREEN).apply { gravity = Gravity.END }
        val bar = SeekBar(c).apply {
            max = SensiCalc.MAX
            progress = init
            progressTintList = ColorStateList.valueOf(CYAN)
            thumbTintList = ColorStateList.valueOf(PURPLE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { value.text = p.toString() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        row.addView(name, LinearLayout.LayoutParams(dp(c, 74), LinearLayout.LayoutParams.WRAP_CONTENT))
        row.addView(bar, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(value, LinearLayout.LayoutParams(dp(c, 40), LinearLayout.LayoutParams.WRAP_CONTENT))
        return row
    }
}
