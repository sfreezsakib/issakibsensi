package com.issakib.sensi

import android.content.Context
import android.content.Intent
import android.widget.Toast

object Games {
    const val FF = "com.dts.freefireth"
    const val MAX = "com.dts.freefiremax"

    fun name(pkg: String) = if (pkg == MAX) "FREE FIRE MAX" else "FREE FIRE"

    fun installed(ctx: Context, pkg: String) =
        ctx.packageManager.getLaunchIntentForPackage(pkg) != null

    fun launch(ctx: Context, pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) {
            Toast.makeText(ctx, "${name(pkg)} not installed", Toast.LENGTH_SHORT).show()
            return false
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return true
    }
}
