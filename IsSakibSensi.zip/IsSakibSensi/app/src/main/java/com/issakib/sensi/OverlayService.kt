package com.issakib.sensi

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import kotlin.math.abs
import kotlin.math.min

class OverlayService : Service() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val muted = 0xFF8FA6C8.toInt()

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var panelFx: Fx? = null
    private val fx = Fx()
    private var pkg = Games.FF

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        pkg = intent?.getStringExtra("pkg") ?: pkg
        startFg()
        if (bubble == null) addBubble()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("sensi", "Sensi overlay", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "sensi")
        else @Suppress("DEPRECATION") Notification.Builder(this)
        val n = b.setContentTitle("IS SENSI")
            .setContentText("Overlay চালু আছে – বন্ধ করতে ট্যাপ করুন")
            .setSmallIcon(android.R.drawable.star_on)
            .setContentIntent(stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )

    private fun addBubble() {
        val c = this
        val win = Ui.dp(c, 78)
        val box = FrameLayout(c)
        val ring = Ui.ring(c, Ui.CYAN, 40)
        val iv = ImageView(c).apply { setImageResource(R.drawable.logo_round) }
        box.addView(ring, FrameLayout.LayoutParams(Ui.dp(c, 56), Ui.dp(c, 56), Gravity.CENTER))
        box.addView(iv, FrameLayout.LayoutParams(Ui.dp(c, 54), Ui.dp(c, 54), Gravity.CENTER))
        fx.ring(ring)
        fx.breathe(iv)

        val p = lp(win, win).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = Ui.dp(c, 110)
        }
        box.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt()
                        val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) { p.x = sx + dx; p.y = sy + dy; wm.updateViewLayout(v, p) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) togglePanel()
                }
                return true
            }
        })
        wm.addView(box, p)
        bubble = box
    }

    private fun togglePanel() { if (panel != null) hidePanel() else showPanel() }

    private fun hidePanel() {
        panelFx?.cancelAll()
        panelFx = null
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }

    private fun showPanel() {
        val c = this
        val pfx = Fx()
        panelFx = pfx
        val info = DeviceInfo.read(c)
        val prof = SensiCalc.profile(info)
        val sens = SensiCalc.suggest(info)
        val (sw, sh) = screenSize()
        val land = sw > sh

        // Host: glowing border, matrix rain, scan line
        val bg = Ui.box(c, 0xF2060814.toInt(), Ui.CYAN, 16)
        pfx.glowBorder(c, bg, Ui.CYAN, Ui.PURPLE)
        val host = FrameLayout(c)
        host.background = bg
        host.setPadding(Ui.dp(c, 3), Ui.dp(c, 3), Ui.dp(c, 3), Ui.dp(c, 3))
        host.clipToOutline = true
        host.outlineProvider = ViewOutlineProvider.BACKGROUND
        host.addView(MatrixRain(c, 45), FrameLayout.LayoutParams(MATCH, MATCH))
        val content = FrameLayout(c)
        host.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
        pfx.scan(c, host)

        // Left: logo + device info
        val left = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10))
        }
        val ls = Ui.dp(c, 54)
        val lbox = FrameLayout(c)
        val ring = Ui.ring(c, Ui.CYAN, 18)
        val logo = Ui.logoView(c, 16)
        lbox.addView(ring, FrameLayout.LayoutParams(ls, ls, Gravity.CENTER))
        lbox.addView(logo, FrameLayout.LayoutParams(ls, ls, Gravity.CENTER))
        left.addView(lbox, LinearLayout.LayoutParams(ls + Ui.dp(c, 22), ls + Ui.dp(c, 22)))
        pfx.ring(ring)
        pfx.breathe(logo)
        val title = Ui.text(c, "IS SENSI", 16f, Ui.CYAN, true, Ui.CYAN).apply { letterSpacing = 0.15f }
        left.addView(title)
        pfx.glowText(title, c, Ui.CYAN, Ui.PURPLE)
        left.addView(Ui.text(c, "BY IS SAKIB", 10f, Ui.PURPLE, true, Ui.PURPLE))
        listOf(
            "GAME   : ${Games.name(pkg)}",
            "PROFILE: $prof"
        ).forEach {
            left.addView(Ui.text(c, "> $it", 9f, Ui.GREEN).apply { setPadding(0, Ui.dp(c, 2), 0, 0) })
        }

        // Right: sliders + buttons
        val right = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 14), Ui.dp(c, 10))
        }
        val head = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(Ui.text(c, "SENSITIVITY", 13f, Ui.CYAN, true, Ui.CYAN), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(Ui.text(c, "✕", 18f, Ui.RED, true).apply {
            setPadding(Ui.dp(c, 12), Ui.dp(c, 2), Ui.dp(c, 4), Ui.dp(c, 2))
            setOnClickListener { hidePanel() }
        })
        right.addView(head)
        val rows = sens.map { Ui.seekRow(c, it.name, it.value) }
        rows.forEachIndexed { i, r ->
            right.addView(r)
            pfx.fadeIn(r, 100L + i * 70L)
        }

        val btns = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, Ui.dp(c, 10), 0, 0)
        }
        val startBtn = Ui.button(c, "▶ START", Ui.GREEN) {
            runTerminal(c, content, pfx, info, prof, sens.map { it.name }, rows)
        }
        val exitBtn = Ui.button(c, "EXIT", Ui.RED) { stopSelf() }
        pfx.glowBorder(c, startBtn.background as GradientDrawable, Ui.GREEN, 0x5539FF14)
        btns.addView(startBtn, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = Ui.dp(c, 8) })
        btns.addView(exitBtn, LinearLayout.LayoutParams(0, WRAP, 1f))
        right.addView(btns)

        if (land) {
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(left, LinearLayout.LayoutParams(0, MATCH, 0.34f))
            row.addView(Ui.scroll(c, right), LinearLayout.LayoutParams(0, MATCH, 0.66f))
            content.addView(row, FrameLayout.LayoutParams(MATCH, MATCH))
        } else {
            val all = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
            all.addView(left, LinearLayout.LayoutParams(MATCH, WRAP))
            all.addView(right, LinearLayout.LayoutParams(MATCH, WRAP))
            content.addView(Ui.scroll(c, all), FrameLayout.LayoutParams(MATCH, MATCH))
        }

        val w = if (land) min((sw * 0.58).toInt(), Ui.dp(c, 440)) else min((sw * 0.88).toInt(), Ui.dp(c, 340))
        val h = if (land) min((sh * 0.8).toInt(), Ui.dp(c, 270)) else min((sh * 0.62).toInt(), Ui.dp(c, 440))
        val p = lp(w, h)
        p.gravity = Gravity.CENTER
        wm.addView(host, p)
        panel = host
    }

    /** START: terminal sequence, then hide panel and bring the game forward. */
    private fun runTerminal(
        c: Context, content: FrameLayout, pfx: Fx, info: Info, prof: String,
        names: List<String>, rows: List<LinearLayout>
    ) {
        content.removeAllViews()

        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(c, 16), Ui.dp(c, 12), Ui.dp(c, 16), Ui.dp(c, 12))
        }
        col.addView(Ui.text(c, "IS SENSI TERMINAL", 13f, Ui.CYAN, true, Ui.CYAN))
        val term = Ui.text(c, "", 11f, Ui.GREEN).apply { setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 8)) }
        col.addView(term, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val barBg = FrameLayout(c).apply { background = Ui.box(c, 0xFF0A0F24.toInt(), Ui.PURPLE, 6) }
        val bar = View(c).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Ui.CYAN, Ui.GREEN)
            ).apply { cornerRadius = Ui.dp(c, 6).toFloat() }
            pivotX = 0f
            scaleX = 0f
        }
        barBg.addView(bar, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(barBg, LinearLayout.LayoutParams(MATCH, Ui.dp(c, 10)))

        val ready = Ui.text(c, "✔ SENSI PROFILE READY", 16f, Ui.GREEN, true, Ui.GREEN).apply {
            gravity = Gravity.CENTER
            alpha = 0f
            setPadding(0, Ui.dp(c, 8), 0, 0)
        }
        col.addView(ready, LinearLayout.LayoutParams(MATCH, WRAP))
        content.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        val lines = ArrayList<String>()
        lines.add("> boot IS-SENSI core ............ OK")
        lines.add("> scanning device .............. OK")
        lines.add("> model   : ${info.model}")
        lines.add("> profile : $prof")
        lines.add("> building sensitivity map .... OK")
        lines.add("> target  : ${Games.name(pkg)}")

        val anim = ObjectAnimator.ofFloat(bar, View.SCALE_X, 0f, 1f).apply {
            duration = 2600
            interpolator = LinearInterpolator()
        }
        pfx.track(anim).start()

        pfx.typeLines(term, lines) {
            ready.animate().alpha(1f).setDuration(400).start()
            pfx.post(1600) {
                hidePanel()
                Games.launch(c, pkg)
            }
        }
    }

    override fun onDestroy() {
        hidePanel()
        fx.cancelAll()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
}
