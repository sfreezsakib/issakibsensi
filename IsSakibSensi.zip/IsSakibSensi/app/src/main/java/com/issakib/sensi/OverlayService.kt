package com.issakib.sensi

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlin.math.abs
import kotlin.math.min

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var bubble: ImageView? = null
    private var panel: View? = null
    private var pkg = Games.FF

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        pkg = intent?.getStringExtra("pkg") ?: pkg
        startFg()
        if (bubble == null) addBubble()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("sensi", "Sensi overlay", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "sensi")
        else @Suppress("DEPRECATION") Notification.Builder(this)
        val n = b.setContentTitle("IS SENSI")
            .setContentText("Overlay চালু আছে – বন্ধ করতে ট্যাপ করুন")
            .setSmallIcon(android.R.drawable.star_on)
            .setContentIntent(stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )

    private fun addBubble() {
        val size = Ui.dp(this, 58)
        val iv = ImageView(this).apply { setImageResource(R.drawable.logo_round) }
        val p = lp(size, size).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = Ui.dp(this@OverlayService, 120)
        }
        iv.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt()
                        val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) { p.x = sx + dx; p.y = sy + dy; wm.updateViewLayout(v, p) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) togglePanel()
                }
                return true
            }
        })
        wm.addView(iv, p)
        bubble = iv
    }

    private fun togglePanel() { if (panel != null) hidePanel() else showPanel() }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }

    private fun showPanel() {
        val c = this
        val info = DeviceInfo.read(c)
        val prof = SensiCalc.profile(info)

        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(c, 16), Ui.dp(c, 12), Ui.dp(c, 16), Ui.dp(c, 14))
        }

        val head = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(c).apply { setImageResource(R.drawable.logo_round) },
            LinearLayout.LayoutParams(Ui.dp(c, 36), Ui.dp(c, 36)))
        head.addView(Ui.text(c, "  IS SENSI", 15f, Ui.CYAN, true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(Ui.text(c, "✕", 18f, Ui.RED, true).apply {
            setPadding(Ui.dp(c, 10), 0, Ui.dp(c, 4), 0)
            setOnClickListener { hidePanel() }
        })
        col.addView(head)

        col.addView(Ui.text(c, "> GAME    : ${Games.name(pkg)}", 11f, Ui.GREEN).apply { setPadding(0, Ui.dp(c, 8), 0, 0) })
        col.addView(Ui.text(c, "> DEVICE  : ${info.model}", 11f, Ui.GREEN))
        col.addView(Ui.text(c, "> RAM/HZ  : ${"%.1f".format(info.ramGb)}GB / ${info.hz.toInt()}Hz / ${info.battery}%", 11f, Ui.GREEN))
        col.addView(Ui.text(c, "> PROFILE : $prof", 11f, Ui.GREEN))
        col.addView(Ui.text(c, "সাজেশন – গেমের Settings → Sensitivity তে সেট করুন", 10f, 0xFF8FA6C8.toInt()).apply {
            setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 4))
        })

        SensiCalc.suggest(info).forEach { col.addView(Ui.seekRow(c, it.name, it.value)) }

        val btns = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, Ui.dp(c, 12), 0, 0) }
        btns.addView(Ui.button(c, "▶ START", Ui.GREEN) { hidePanel(); Games.launch(c, pkg) },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = Ui.dp(c, 8) })
        btns.addView(Ui.button(c, "EXIT", Ui.RED) { stopSelf() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(btns)

        val scroll = ScrollView(c).apply { background = Ui.box(c); addView(col) }
        val (sw, sh) = screenSize()
        val p = lp(min((sw * 0.92).toInt(), Ui.dp(c, 430)), min((sh * 0.92).toInt(), Ui.dp(c, 500)))
        p.gravity = Gravity.CENTER
        wm.addView(scroll, p)
        panel = scroll
    }

    override fun onDestroy() {
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
}
