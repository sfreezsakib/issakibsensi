package com.issakib.sensi

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min

data class Info(
    val model: String,
    val androidVer: String,
    val ramGb: Double,
    val hz: Float,
    val res: String,
    val dpi: Int,
    val battery: Int
)

object DeviceInfo {
    @Suppress("DEPRECATION")
    fun read(ctx: Context): Info {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val hz = wm.defaultDisplay.refreshRate
        val dm = ctx.resources.displayMetrics
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val model = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
        return Info(
            model,
            "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            mi.totalMem / 1073741824.0,
            hz,
            "${max(dm.widthPixels, dm.heightPixels)}x${min(dm.widthPixels, dm.heightPixels)}",
            dm.densityDpi,
            bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        )
    }
}
