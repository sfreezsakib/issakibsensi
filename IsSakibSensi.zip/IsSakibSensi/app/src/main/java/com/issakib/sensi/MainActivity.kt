package com.issakib.sensi

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val muted = 0xFF8FA6C8.toInt()
    private lateinit var col: LinearLayout
    private val fx = Fx()
    private var pendingKey: String? = null
    private var leftAt = 0L
    private var typed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val c = this
        col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(Ui.dp(c, 18), Ui.dp(c, 20), Ui.dp(c, 18), Ui.dp(c, 30))
        }
        val root = FrameLayout(c).apply { setBackgroundColor(0xFF03040A.toInt()) }
        root.addView(MatrixRain(c, 70), FrameLayout.LayoutParams(-1, -1))
        val scroll = ScrollView(c).apply {
            isVerticalScrollBarEnabled = false
            addView(col)
        }
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        render()
    }

    override fun onDestroy() {
        fx.cancelAll()
        super.onDestroy()
    }

    override fun onPause() {
        super.onPause()
        if (pendingKey != null && leftAt == 0L) leftAt = SystemClock.elapsedRealtime()
    }

    override fun onResume() {
        super.onResume()
        val key = pendingKey
        if (key != null && leftAt > 0L) {
            val stayed = SystemClock.elapsedRealtime() - leftAt
            pendingKey = null
            leftAt = 0L
            if (stayed >= 5000) {
                Gate.markDone(this, key)
                if (Gate.unlocked(this)) {
                    Toast.makeText(this, "✔ ACCESS GRANTED", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "✔ Verified", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "আরেকটু সময় নিয়ে Follow/Subscribe করে ফিরে আসুন", Toast.LENGTH_LONG).show()
            }
            render()
        }
    }

    private fun top(dp: Int) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = Ui.dp(this@MainActivity, dp) }

    private fun center(tv: TextView) = tv.apply { gravity = Gravity.CENTER }

    private fun render() {
        val c = this
        fx.cancelAll()
        col.removeAllViews()
        val info = DeviceInfo.read(c)
        val prof = SensiCalc.profile(info)

        // Glowing logo with pulse rings
        val s = Ui.dp(c, 170)
        val box = FrameLayout(c)
        val ring1 = Ui.ring(c, Ui.CYAN, 30)
        val ring2 = Ui.ring(c, Ui.PURPLE, 30)
        val logo = Ui.logoView(c, 26)
        box.addView(ring1, FrameLayout.LayoutParams(s, s, Gravity.CENTER))
        box.addView(ring2, FrameLayout.LayoutParams(s, s, Gravity.CENTER))
        box.addView(logo, FrameLayout.LayoutParams(s, s, Gravity.CENTER))
        col.addView(box, LinearLayout.LayoutParams(Ui.dp(c, 240), Ui.dp(c, 240)))
        fx.ring(ring1, 0)
        fx.ring(ring2, 1100)
        fx.breathe(logo)

        val title = center(Ui.text(c, "IS SENSI", 28f, Ui.CYAN, true, Ui.CYAN)).apply { letterSpacing = 0.15f }
        col.addView(title, top(2))
        fx.glowText(title, c, Ui.CYAN, Ui.PURPLE)
        col.addView(center(Ui.text(c, "BY IS SAKIB", 11f, Ui.PURPLE, true, Ui.PURPLE)).apply { letterSpacing = 0.3f }, top(2))

        // Terminal console with scan line
        val consoleBg = Ui.box(c, 0xE60A0F24.toInt(), Ui.PURPLE)
        val consoleBox = FrameLayout(c).apply { background = consoleBg }
        val console = Ui.text(c, "", 12f, Ui.GREEN).apply {
            setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10))
        }
        consoleBox.addView(console)
        fx.scan(c, consoleBox)
        col.addView(consoleBox, top(14))
        fx.glowBorder(c, consoleBg, Ui.PURPLE, Ui.CYAN)
        fx.fadeIn(consoleBox, 150)

        val lines = listOf(
            "> DEVICE  : ${info.model}",
            "> OS      : ${info.androidVer}",
            "> RAM     : ${"%.1f".format(info.ramGb)} GB",
            "> DISPLAY : ${info.res} @ ${info.hz.toInt()}Hz / ${info.dpi}dpi",
            "> BATTERY : ${info.battery}%",
            "> PROFILE : $prof",
            "> STATUS  : ${if (Gate.unlocked(c)) "ACCESS GRANTED" else "LOCKED"}"
        )
        if (!typed) {
            typed = true
            fx.typeLines(console, lines) { }
        } else {
            console.text = lines.joinToString("\n")
        }

        if (Gate.unlocked(c)) unlockedSection() else gateSection()
    }

    private fun gateSection() {
        val c = this
        val lock = center(Ui.text(c, "🔒 PANEL LOCKED", 18f, Ui.RED, true, Ui.RED))
        col.addView(lock, top(20))
        fx.blink(lock)
        col.addView(
            center(Ui.text(c, "নিচের সবগুলোতে Follow / Subscribe করুন।\nপ্রতিটায় ঢুকে অন্তত ৫ সেকেন্ড থেকে অ্যাপে ফিরে আসুন।", 11f, muted)),
            top(6)
        )

        val done = Gate.count(c)
        val bar = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        Gate.tasks.forEachIndexed { i, t ->
            val seg = View(c).apply {
                background = Ui.box(c, if (Gate.done(c, t.key)) Ui.GREEN else 0xFF1A2040.toInt(), 0x00000000, 4)
            }
            bar.addView(seg, LinearLayout.LayoutParams(0, Ui.dp(c, 8), 1f).apply {
                if (i > 0) leftMargin = Ui.dp(c, 4)
            })
        }
        col.addView(bar, top(14))
        col.addView(center(Ui.text(c, "$done / ${Gate.tasks.size} COMPLETED", 12f, Ui.CYAN, true, Ui.CYAN)), top(6))

        Gate.tasks.forEachIndexed { i, t ->
            val card = taskCard(t)
            col.addView(card, top(10))
            fx.fadeIn(card, 250L + i * 110L)
        }

        col.addView(
            center(Ui.text(c, "একবার সব সম্পন্ন হলে এই স্ক্রিন আর কখনো আসবে না ✔", 11f, muted)),
            top(16)
        )
    }

    private fun taskCard(t: Task): LinearLayout {
        val c = this
        val done = Gate.done(c, t.key)
        val bg = Ui.box(c, 0xE60A0F24.toInt(), if (done) Ui.GREEN else t.color)
        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12))
            background = bg
        }
        if (!done) fx.glowBorder(c, bg, t.color, (t.color and 0x00FFFFFF) or 0x44000000)
        row.addView(Ui.text(c, t.icon, 22f, if (done) Ui.GREEN else t.color, true, if (done) Ui.GREEN else t.color).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(Ui.dp(c, 36), LinearLayout.LayoutParams.WRAP_CONTENT))
        val names = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        names.addView(Ui.text(c, t.title, 14f, 0xFFFFFFFF.toInt(), true))
        names.addView(Ui.text(c, t.sub, 11f, muted))
        row.addView(names, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Ui.text(c, if (done) "✔ DONE" else "JOIN ▶", 12f, if (done) Ui.GREEN else t.color, true, if (done) Ui.GREEN else t.color))
        if (!done) row.setOnClickListener { openTask(t) }
        return row
    }

    private fun openTask(t: Task) {
        pendingKey = t.key
        leftAt = 0L
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(t.url)))
        } catch (e: Exception) {
            pendingKey = null
            Toast.makeText(this, "লিংক খোলা যাচ্ছে না", Toast.LENGTH_SHORT).show()
        }
    }

    private fun unlockedSection() {
        val c = this
        val ok = center(Ui.text(c, "✔ ACCESS GRANTED", 18f, Ui.GREEN, true, Ui.GREEN))
        col.addView(ok, top(20))
        fx.glowText(ok, c, Ui.GREEN, Ui.CYAN)
        col.addView(center(Ui.text(c, "SELECT GAME", 13f, Ui.TEXT, true)), top(14))

        val b1 = Ui.button(c, "▶  FREE FIRE", Ui.CYAN) { start(Games.FF) }
        col.addView(b1, top(8))
        fx.glowBorder(c, b1.background as GradientDrawable, Ui.CYAN, 0x5500E5FF)
        fx.fadeIn(b1, 200)

        val b2 = Ui.button(c, "▶  FREE FIRE MAX", Ui.PURPLE) { start(Games.MAX) }
        col.addView(b2, top(10))
        fx.glowBorder(c, b2.background as GradientDrawable, Ui.PURPLE, 0x55B026FF)
        fx.fadeIn(b2, 320)

        col.addView(
            center(Ui.text(c,
                "গেম খুলবে, তারপর স্ক্রিনে লোগো ভাসবে। লোগোতে ট্যাপ করলে প্যানেল আসবে।\n" +
                    "প্যানেলের মানগুলো শুধু সাজেশন – গেমের Settings → Sensitivity তে নিজে সেট করে নিতে হবে।",
                11f, muted)),
            top(16)
        )
    }

    private fun start(pkg: String) {
        if (!Gate.unlocked(this)) { render(); return }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission দিন, তারপর আবার চাপুন", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!Games.installed(this, pkg)) {
            Toast.makeText(this, "${Games.name(pkg)} ইনস্টল করা নেই", Toast.LENGTH_LONG).show()
            return
        }
        val svc = Intent(this, OverlayService::class.java).putExtra("pkg", pkg)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
        Games.launch(this, pkg)
        finish()
    }
}
