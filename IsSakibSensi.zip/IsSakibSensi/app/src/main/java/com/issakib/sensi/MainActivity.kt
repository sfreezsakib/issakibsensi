package com.issakib.sensi

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val muted = 0xFF8FA6C8.toInt()
    private lateinit var col: LinearLayout
    private var pendingKey: String? = null
    private var leftAt = 0L
    private var typed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(Ui.dp(this@MainActivity, 18), Ui.dp(this@MainActivity, 26), Ui.dp(this@MainActivity, 18), Ui.dp(this@MainActivity, 30))
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF05060F.toInt())
            addView(col)
        })
        render()
    }

    override fun onPause() {
        super.onPause()
        if (pendingKey != null && leftAt == 0L) leftAt = SystemClock.elapsedRealtime()
    }

    override fun onResume() {
        super.onResume()
        val key = pendingKey
        if (key != null && leftAt > 0L) {
            val stayed = SystemClock.elapsedRealtime() - leftAt
            pendingKey = null
            leftAt = 0L
            if (stayed >= 5000) {
                Gate.markDone(this, key)
                if (Gate.unlocked(this)) {
                    Toast.makeText(this, "✔ ACCESS GRANTED", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "✔ Verified", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "আরেকটু সময় নিয়ে Follow/Subscribe করে ফিরে আসুন", Toast.LENGTH_LONG).show()
            }
            render()
        }
    }

    private fun top(dp: Int) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = Ui.dp(this@MainActivity, dp) }

    private fun center(tv: TextView) = tv.apply { gravity = Gravity.CENTER }

    private fun render() {
        val c = this
        col.removeAllViews()
        val info = DeviceInfo.read(c)
        val prof = SensiCalc.profile(info)

        col.addView(
            ImageView(c).apply { setImageResource(R.drawable.logo) },
            LinearLayout.LayoutParams(Ui.dp(c, 180), Ui.dp(c, 180))
        )
        col.addView(center(Ui.text(c, "◢ IS SENSI ◣", 22f, Ui.CYAN, true)), top(6))
        col.addView(center(Ui.text(c, "BY IS SAKIB", 11f, Ui.PURPLE, true)), top(2))

        val console = Ui.text(c, "", 12f, Ui.GREEN).apply {
            setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10))
            background = Ui.box(c, 0xFF0A0F24.toInt(), Ui.PURPLE)
        }
        col.addView(console, top(14))
        val full = "> DEVICE  : ${info.model}\n" +
            "> OS      : ${info.androidVer}\n" +
            "> RAM     : ${"%.1f".format(info.ramGb)} GB\n" +
            "> DISPLAY : ${info.res} @ ${info.hz.toInt()}Hz / ${info.dpi}dpi\n" +
            "> BATTERY : ${info.battery}%\n" +
            "> PROFILE : $prof\n" +
            "> STATUS  : ${if (Gate.unlocked(c)) "ACCESS GRANTED" else "LOCKED"}"
        if (!typed) { typed = true; typeWriter(console, full) } else console.text = full

        if (Gate.unlocked(c)) unlockedSection() else gateSection()
    }

    private fun gateSection() {
        val c = this
        col.addView(center(Ui.text(c, "🔒 PANEL LOCKED", 17f, Ui.RED, true)), top(20))
        col.addView(
            center(Ui.text(c, "নিচের সবগুলোতে Follow / Subscribe করুন।\nপ্রতিটায় ঢুকে অন্তত ৫ সেকেন্ড থেকে অ্যাপে ফিরে আসুন।", 11f, muted)),
            top(6)
        )

        val done = Gate.count(c)
        val bar = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        Gate.tasks.forEachIndexed { i, t ->
            val seg = View(c).apply {
                background = Ui.box(c, if (Gate.done(c, t.key)) Ui.GREEN else 0xFF1A2040.toInt(), 0x00000000, 4)
            }
            bar.addView(seg, LinearLayout.LayoutParams(0, Ui.dp(c, 8), 1f).apply {
                if (i > 0) leftMargin = Ui.dp(c, 4)
            })
        }
        col.addView(bar, top(14))
        col.addView(center(Ui.text(c, "$done / ${Gate.tasks.size} COMPLETED", 12f, Ui.CYAN, true)), top(6))

        Gate.tasks.forEach { col.addView(taskCard(it), top(10)) }

        col.addView(
            center(Ui.text(c, "একবার সব সম্পন্ন হলে এই স্ক্রিন আর কখনো আসবে না ✔", 11f, muted)),
            top(16)
        )
    }

    private fun taskCard(t: Task): LinearLayout {
        val c = this
        val done = Gate.done(c, t.key)
        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12))
            background = Ui.box(c, 0xFF0A0F24.toInt(), if (done) Ui.GREEN else t.color)
        }
        row.addView(Ui.text(c, t.icon, 22f, if (done) Ui.GREEN else t.color, true).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(Ui.dp(c, 36), LinearLayout.LayoutParams.WRAP_CONTENT))
        val names = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        names.addView(Ui.text(c, t.title, 14f, 0xFFFFFFFF.toInt(), true))
        names.addView(Ui.text(c, t.sub, 11f, muted))
        row.addView(names, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Ui.text(c, if (done) "✔ DONE" else "JOIN ▶", 12f, if (done) Ui.GREEN else t.color, true))
        if (!done) row.setOnClickListener { openTask(t) }
        return row
    }

    private fun openTask(t: Task) {
        pendingKey = t.key
        leftAt = 0L
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(t.url)))
        } catch (e: Exception) {
            pendingKey = null
            Toast.makeText(this, "লিংক খোলা যাচ্ছে না", Toast.LENGTH_SHORT).show()
        }
    }

    private fun unlockedSection() {
        val c = this
        col.addView(center(Ui.text(c, "✔ ACCESS GRANTED", 17f, Ui.GREEN, true)), top(20))
        col.addView(center(Ui.text(c, "SELECT GAME", 13f, Ui.TEXT, true)), top(14))
        col.addView(Ui.button(c, "▶  FREE FIRE", Ui.CYAN) { start(Games.FF) }, top(8))
        col.addView(Ui.button(c, "▶  FREE FIRE MAX", Ui.PURPLE) { start(Games.MAX) }, top(10))
        col.addView(
            center(Ui.text(c,
                "গেম খুলবে, তারপর স্ক্রিনে লোগো ভাসবে। লোগোতে ট্যাপ করলে প্যানেল আসবে।\n" +
                    "প্যানেলের মানগুলো শুধু সাজেশন – গেমের Settings → Sensitivity তে নিজে সেট করে নিতে হবে।",
                11f, muted)),
            top(16)
        )
    }

    private fun start(pkg: String) {
        if (!Gate.unlocked(this)) { render(); return }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission দিন, তারপর আবার চাপুন", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!Games.installed(this, pkg)) {
            Toast.makeText(this, "${Games.name(pkg)} ইনস্টল করা নেই", Toast.LENGTH_LONG).show()
            return
        }
        val svc = Intent(this, OverlayService::class.java).putExtra("pkg", pkg)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
        Games.launch(this, pkg)
        finish()
    }

    private fun typeWriter(tv: TextView, full: String) {
        val h = Handler(Looper.getMainLooper())
        var i = 0
        h.post(object : Runnable {
            override fun run() {
                if (i < full.length) {
                    tv.text = full.substring(0, i) + "█"
                    i += 2
                    h.postDelayed(this, 14)
                } else {
                    tv.text = full
                }
            }
        })
    }
}
