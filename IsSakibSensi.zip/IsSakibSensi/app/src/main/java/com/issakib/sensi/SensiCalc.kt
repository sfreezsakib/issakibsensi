package com.issakib.sensi

data class Sensi(val name: String, val value: Int)

/** Starting-point suggestions only. Fine-tune in Free Fire's training ground. */
object SensiCalc {
    fun profile(i: Info) = when {
        i.ramGb >= 7 && i.hz >= 90 -> "FLAGSHIP"
        i.ramGb >= 3.5 -> "BALANCED"
        else -> "ENTRY"
    }

    fun suggest(i: Info): List<Sensi> {
        val adj = when (profile(i)) {
            "FLAGSHIP" -> -4
            "ENTRY" -> 2
            else -> 0
        }
        fun v(base: Int) = (base + adj).coerceIn(0, 100)
        return listOf(
            Sensi("General", v(90)),
            Sensi("Red Dot", v(85)),
            Sensi("2x Scope", v(80)),
            Sensi("4x Scope", v(75)),
            Sensi("AWM Scope", v(62)),
            Sensi("Free Look", v(85))
        )
    }
}
