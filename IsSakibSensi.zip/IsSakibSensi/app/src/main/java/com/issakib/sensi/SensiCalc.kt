package com.issakib.sensi

data class Sensi(val name: String, val value: Int)

/** Free Fire sensitivity range is 0-200. Starting-point suggestions only. */
object SensiCalc {
    const val MAX = 200

    fun profile(i: Info) = when {
        i.ramGb >= 7 && i.hz >= 90 -> "FLAGSHIP"
        i.ramGb >= 3.5 -> "BALANCED"
        else -> "ENTRY"
    }

    fun suggest(i: Info): List<Sensi> {
        val adj = when (profile(i)) {
            "FLAGSHIP" -> -8
            "ENTRY" -> 4
            else -> 0
        }
        fun v(base: Int) = (base + adj).coerceIn(0, MAX)
        return listOf(
            Sensi("General", v(180)),
            Sensi("Red Dot", v(170)),
            Sensi("2x Scope", v(160)),
            Sensi("4x Scope", v(150)),
            Sensi("AWM Scope", v(125)),
            Sensi("Free Look", v(170))
        )
    }
}
